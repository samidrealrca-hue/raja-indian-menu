@echo off
title Raja Indian Restaurant - Menu
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (echo Node.js غير مثبت. ثبّت Node.js ثم أعد المحاولة.&pause&exit /b 1)
if not exist node_modules (
  echo جاري تثبيت ملفات المشروع... الرجاء الانتظار.
  call npm install
  if errorlevel 1 (echo فشل تثبيت الملفات.&pause&exit /b 1)
)
echo.
echo تم تشغيل سيرفر راجا على http://localhost:3000
echo اترك هذه النافذة مفتوحة أثناء استخدام الموقع.
start "" http://localhost:3000
call npm start
pause
