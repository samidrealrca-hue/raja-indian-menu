import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import cookieParser from "cookie-parser";
import multer from "multer";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || "raja-change-this-secret";
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || "admin@raja.local";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "ChangeMe123!";
const dataDir = path.join(__dirname, "data");
const uploadDir = path.join(__dirname, "public", "uploads");
const dbFile = path.join(dataDir, "raja-data.json");
fs.mkdirSync(dataDir,{recursive:true}); fs.mkdirSync(uploadDir,{recursive:true});

const seedCategories=[
 {id:1,name_ar:"أطباق مميزة",name_en:"Special Dishes",sort_order:1,active:1},
 {id:2,name_ar:"المقبلات",name_en:"Appetizers",sort_order:2,active:1},
 {id:3,name_ar:"التندوري",name_en:"Tandoori",sort_order:3,active:1},
 {id:4,name_ar:"الدجاج",name_en:"Chicken",sort_order:4,active:1},
 {id:5,name_ar:"اللحوم",name_en:"Meat",sort_order:5,active:1},
 {id:6,name_ar:"المأكولات البحرية",name_en:"Seafood",sort_order:6,active:1},
 {id:7,name_ar:"الأطباق النباتية",name_en:"Vegetarian",sort_order:7,active:1},
 {id:8,name_ar:"البرياني والأرز",name_en:"Biryani & Rice",sort_order:8,active:1},
 {id:9,name_ar:"الخبز الهندي",name_en:"Indian Breads",sort_order:9,active:1},
 {id:10,name_ar:"الحلويات",name_en:"Desserts",sort_order:10,active:1},
 {id:11,name_ar:"المشروبات",name_en:"Drinks",sort_order:11,active:1}
];
function load(){if(!fs.existsSync(dbFile)){const db={nextCatId:12,nextDishId:1,categories:seedCategories,dishes:[],admins:[{id:1,email:ADMIN_EMAIL,password_hash:bcrypt.hashSync(ADMIN_PASSWORD,10)}]};save(db);return db} return JSON.parse(fs.readFileSync(dbFile,"utf8"));}
let db=load();
function save(x=db){fs.writeFileSync(dbFile,JSON.stringify(x,null,2),"utf8");}
function auth(req,res,next){try{const t=req.cookies.raja_admin;if(!t)throw 0;req.admin=jwt.verify(t,JWT_SECRET);next()}catch{res.status(401).json({error:"غير مصرح أو انتهت الجلسة"})}}
function tokenFor(a){return jwt.sign({id:a.id,email:a.email},JWT_SECRET,{expiresIn:"7d"})}
app.use(express.json({limit:"2mb"}));app.use(cookieParser());app.use(express.static(path.join(__dirname,"public")));
const upload=multer({storage:multer.diskStorage({destination:uploadDir,filename:(_,f,cb)=>cb(null,`${Date.now()}-${Math.random().toString(36).slice(2)}${path.extname(f.originalname).toLowerCase()||'.jpg'}`)}),limits:{fileSize:5*1024*1024},fileFilter:(_,f,cb)=>cb(null,/^image\/(jpeg|png|webp)$/.test(f.mimetype))});
app.get('/api/menu',(req,res)=>{const categories=db.categories.filter(c=>c.active).sort((a,b)=>a.sort_order-b.sort_order);const dishes=db.dishes.filter(d=>d.active&&categories.some(c=>c.id===d.category_id)).sort((a,b)=>b.featured-a.featured||b.id-a.id);res.json({categories,dishes})});
app.post('/api/admin/login',(req,res)=>{const {email,password}=req.body||{};const a=db.admins.find(x=>x.email===email);if(!a||!bcrypt.compareSync(password||'',a.password_hash))return res.status(401).json({error:'البريد أو كلمة المرور غير صحيحة'});res.cookie('raja_admin',tokenFor(a),{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:7*24*60*60*1000});res.json({ok:true})});
app.post('/api/admin/logout',(req,res)=>{res.clearCookie('raja_admin');res.json({ok:true})});
app.get('/api/admin/me',auth,(req,res)=>res.json({email:req.admin.email}));
app.get('/api/admin/categories',auth,(req,res)=>res.json([...db.categories].sort((a,b)=>a.sort_order-b.sort_order||a.id-b.id)));
app.post('/api/admin/categories',auth,(req,res)=>{const {name_ar,name_en,sort_order=0}=req.body||{};if(!name_ar||!name_en)return res.status(400).json({error:'أدخل اسم القسم'});const id=db.nextCatId++;db.categories.push({id,name_ar,name_en,sort_order:Number(sort_order),active:1});save();res.json({id})});
app.put('/api/admin/categories/:id',auth,(req,res)=>{const c=db.categories.find(x=>x.id===Number(req.params.id));if(!c)return res.status(404).json({error:'القسم غير موجود'});const {name_ar,name_en,sort_order,active}=req.body;c.name_ar=name_ar??c.name_ar;c.name_en=name_en??c.name_en;c.sort_order=Number(sort_order??c.sort_order);c.active=active?1:0;save();res.json({ok:true})});
app.get('/api/admin/dishes',auth,(req,res)=>res.json([...db.dishes].sort((a,b)=>b.featured-a.featured||b.id-a.id)));
app.post('/api/admin/dishes',auth,(req,res)=>{const p=req.body||{};if(!p.category_id||!p.name_ar||!p.name_en)return res.status(400).json({error:'البيانات الأساسية ناقصة'});const id=db.nextDishId++;db.dishes.push({id,category_id:Number(p.category_id),name_ar:p.name_ar,name_en:p.name_en,description_ar:p.description_ar||'',description_en:p.description_en||'',price:Number(p.price||0),image:p.image||'',featured:p.featured?1:0,active:1});save();res.json({id})});
app.put('/api/admin/dishes/:id',auth,(req,res)=>{const d=db.dishes.find(x=>x.id===Number(req.params.id));if(!d)return res.status(404).json({error:'الطبق غير موجود'});Object.assign(d,{category_id:Number(req.body.category_id??d.category_id),name_ar:req.body.name_ar??d.name_ar,name_en:req.body.name_en??d.name_en,description_ar:req.body.description_ar??d.description_ar,description_en:req.body.description_en??d.description_en,price:Number(req.body.price??d.price),image:req.body.image??d.image,featured:req.body.featured?1:0,active:req.body.active?1:0});save();res.json({ok:true})});
app.delete('/api/admin/dishes/:id',auth,(req,res)=>{const d=db.dishes.find(x=>x.id===Number(req.params.id));if(d){d.active=0;save()}res.json({ok:true})});
app.post('/api/admin/upload',auth,upload.single('image'),(req,res)=>{if(!req.file)return res.status(400).json({error:'الصورة غير صالحة'});res.json({url:'/uploads/'+req.file.filename})});
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`Raja menu running on http://localhost:${PORT}`));
